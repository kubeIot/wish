/**
 * Created by skylele on 5.3.17.
 */
/**
 * Created by skytzi on 6.2.17.
 */
import {Injectable} from '@angular/core';
import {Http, Headers, Response} from "@angular/http";
import 'rxjs/add/operator/map';

@Injectable()
export class testService {

    private _url: string = "http://date.jsontest.com";
    constructor (private _http: Http) {
    }

    getCurrentTime() {
        console.log("getting the time from " + this._url);
        return this._http.get(this._url)
            .map((response:Response) => response.json());
    }

}